#include <iostream>
#include <ctime>
#include <stdlib.h>
using namespace std;

void intializeGameBoard(int*);
void displayGameBoard(int*);
void makeMove(int*);
bool checkWinner(int*);
int checkMove(int*);
void declareWinner(int*, int);
/**
  State 0: Unoccupied
  State 1: Contains an X
  State 2: Cntains an O
 */
int main() {
  cout << "Welcome to Tic Tac Toe!"<<endl<<"Here is the game board:"<<endl;
  int *gameBoard = new int[9];
  intializeGameBoard(gameBoard);
  displayGameBoard(gameBoard);
  makeMove(gameBoard);

}
/**Iterates memory locations and displays contents in grid
  0- space
  1- X
  2- O
  Receives: gameBoard integer pointer
  Returns: Nothing
  */
void displayGameBoard(int *s){
  for(int i = 0; i < 9; i++){
    cout<<" ";
    if(*(s+i) == 0 ){
      cout<<" ";
    }
    else if(*(s+i) == 1 ){
      cout<<"X";
    }
    else if(*(s+i) == 2 ){
      cout<<"O";
    }
    cout<<"  ";
    if(i == 2 || i ==5){
      cout<<endl<<"_____________"<<endl;
    }
    else if(i == 8){
      cout<<endl;
    }
    else{
      cout<<"|";
    }
  }
}

/** Puts a value 0 in every memory location 
    Receives: reference to gameBoard integer pointer
    Returns: Nothing
  */
void intializeGameBoard(int*s){
  for(int i = 0; i < 9; i++){
   *(s + i) = 0;
  }
}
/** Randomly chooses which player goes first
    Prompts user to choose row and column(Checks Input)
    Calls checkWinner method until winner or draw 
  */
void makeMove(int *s){
  //Randomly chooses which player goes first
  srand(time(0));
  int random = rand() % 10 +1;
  int state = random % 2; 
  bool winner = false;
  //Loops until game ends (calls checkMove and checkWinner)
  while(!winner){
  if (state % 2 == 0){
    cout<<"It is player X's turn."<<endl;
  }
  else{
    cout<<"It is player O's turn."<<endl;
  }
  int location = checkMove(s);

  if(state % 2 == 0){
    *(s + location) = 1;   
  }
  else{
    *(s + location) = 2;   
  }
  displayGameBoard(s);
  state = state + 1;
  winner = checkWinner(s);
  }
}
/*Prompts user for row and column 
  Then calculates row and column to match location on gameboard
 */
int checkMove(int *s){
  int row, column;
  bool valid = false; 
  while(!valid){
    cout<<"Enter row #: ";
    cin>>row;
    while(row < 0 || row > 2){
      cout<<"Please enter a valid input (0-2)";
      cin>>row;
    }
    row = row * 3;
    cout<<"Enter column #:";
    cin>>column;
    while(column < 0 || column > 2){
      cout<<"Please enter a valid input (0-2)";
      cin>>column;
    }
    //return row + column;
    if(*(s + row + column) != 0){
      cout<<"Cell taken! Try again"<<endl;
      valid = false;
    }
    else{
      valid = true;
      return row + column;
    }
  }
  return 0;
}
bool checkWinner(int* s){
  //Checks if the \ diagonal is the same
  if(*(s) == *(s + 4) && *(s + 4) == *(s + 8) && *(s) != 0){
    declareWinner(s, 4);
    return true;
  }
  //Checks if the / diagonal is the same
  else if(*(s + 2) == *(s + 4) && *(s + 4) == *(s + 6) && *(s + 2) != 0){
    declareWinner(s, 4);
    return true;
  }
  //Checks straight lines
  for (int i = 0; i < 3; i++){
    //Vertical lines
    if(*(s + i) == *(s + i + 3) && *(s + i + 3) == *(s + i + 6) && *(s + i) != 0){
      declareWinner(s, i);
      return true;
    }
    //Horizontal lines
    else if(*(s + (i * 3)) == *(s + (i * 3) + 1) && *(s + (i * 3) + 1) == *(s + (i * 3) + 2) && *(s + (i * 3)) != 0 ){
      declareWinner(s, i * 3);
      return true;
    }
  }
  for(int i = 0; i < 9; i++){
    //Checks for empty cell, if  there is one, keep playing the game
    if(*(s+ i) == 0){
      return false;
    }
  }
  //If program reaches here, then there were no empty cells and no winner
  cout<<"It's a draw!";
  return true;
}
//Prints out winner
//Takes in location (one of them) and the pointer
//Returns: nothing
void declareWinner(int *s, int i){
  if(*(s+ i) == 1){
    cout<<"Player X wins!";
  }
  else{
    cout<<"Player O wins!";
  }

}
   
